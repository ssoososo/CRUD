//
//  Test.swift
//  LoverApp
//
//  Created by User09 on 2020/5/17.
//  Copyright © 2020 SHIH-YING PAN. All rights reserved.
//

import SwiftUI

struct Test: View {
    @State private var trimEnd: CGFloat = 0
    
    var body: some View {
        
        VStack {
            Circle()
                .trim(from: CGFloat(0), to: trimEnd)
                .stroke(Color.blue, style: StrokeStyle(lineWidth: 30,
                                                       lineCap: .round))
                .frame(width: 300, height: 300)
                .animation(.linear(duration: 2))
                .onAppear {
                    self.trimEnd = 0.9
            }
            
            
        }
        
    }
}

struct Test_Previews: PreviewProvider {
    static var previews: some View {
        Test()
    }
}
