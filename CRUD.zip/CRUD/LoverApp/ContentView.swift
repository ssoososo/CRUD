//
//  ContentView.swift
//  LoverApp
//
//  Created by SHIH-YING PAN on 2020/4/29.
//  Copyright © 2020 SHIH-YING PAN. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var loversData = LoversData()
    @State private var trimEnd1: CGFloat = 0
    @State private var trimEnd2: CGFloat = 0
    @State private var trimEnd3: CGFloat = 0
    var totalHot:Int=0
    var totalCarbohydrate:Double=0
    var totalProtein:Double=0
    var totalGrease:Double=0
    var percentages: [Double] = [0, 0, 0]
    var carbohydratePosition: [Double] = [0,  0]
    var proteinPosition: [Double] = [0,  0]
    var greasePosition: [Double] = [0,  0]
    @State var position1:[CGFloat]=[0,0]
    @State var position2:[CGFloat]=[0,0]
    @State var position3:[CGFloat]=[0,0]
    
    init(loversData: LoversData) {
        self.loversData = loversData
        for data in loversData.lovers {
            totalHot += data.carbohydrate*4+data.protein*4+data.grease*9
            totalCarbohydrate+=Double(data.carbohydrate)
            totalProtein+=Double(data.protein)
            totalGrease+=Double(data.grease)
        }
        percentages[0]=totalCarbohydrate/(totalCarbohydrate+totalProtein+totalGrease)*100
        percentages[1]=totalProtein/(totalCarbohydrate+totalProtein+totalGrease)*100
        percentages[2]=totalGrease/(totalCarbohydrate+totalProtein+totalGrease)*100
        
        carbohydratePosition[0]=(150.0)*cos(totalCarbohydrate/2/(totalCarbohydrate+totalProtein+totalGrease)*6.28)
        carbohydratePosition[1]=(150.0)*sin(totalCarbohydrate/2/(totalCarbohydrate+totalProtein+totalGrease)*6.28)
        
        
        proteinPosition[0]=(150.0)*cos((totalCarbohydrate+totalProtein/2)/(totalCarbohydrate+totalProtein+totalGrease)*6.28)
        proteinPosition[1]=(150.0)*sin((totalCarbohydrate+totalProtein/2)/(totalCarbohydrate+totalProtein+totalGrease)*6.28)
        
        greasePosition[0]=(150.0)*cos((totalCarbohydrate+totalProtein+totalGrease/2)/(totalCarbohydrate+totalProtein+totalGrease)*6.28)
        greasePosition[1]=(150.0)*sin((totalCarbohydrate+totalProtein+totalGrease/2)/(totalCarbohydrate+totalProtein+totalGrease)*6.28)
        
        
    }
    
    var body: some View {
        ZStack {
            Group{
                Circle()
                    .trim(from: 0, to: trimEnd1)
                    .stroke(Color.red, lineWidth: 30)
                    .animation(.linear(duration: 1))
                    .onAppear {self.trimEnd1 = 1 }
                Circle()
                    .trim(from: 0, to: trimEnd2)
                    .stroke(Color.blue, lineWidth: 30)
                    .animation(.linear(duration: 1))
                    .onAppear {self.trimEnd2 = CGFloat((self.totalCarbohydrate+self.totalProtein)/(self.totalCarbohydrate+self.totalProtein+self.totalGrease)) }
                Circle()
                    .trim(from: 0, to: trimEnd3)
                    .stroke(Color.yellow, lineWidth: 30)
                    .animation(.linear(duration: 1))
                    .onAppear {self.trimEnd3 = CGFloat(self.totalCarbohydrate/(self.totalCarbohydrate+self.totalProtein+self.totalGrease)) }
            }
            RoundedRectangle(cornerRadius:30)
                .fill(Color(red:0.4,green:0.7,blue:0.7))
                .frame(width:80, height:40)
                .offset(x:position1[0],y:position1[1])
                .animation(.linear(duration: 1))
                .onAppear {
                    self.position1[0] = CGFloat(self.carbohydratePosition[0])
                    self.position1[1] = CGFloat(self.carbohydratePosition[1])
                    
            }
            
            RoundedRectangle(cornerRadius:30)
                .fill(Color(red:0.4,green:0.7,blue:0.7))
                .frame(width:80, height:40)
                .offset(x: position2[0], y: position2[1])
                .animation(.linear(duration: 1))
                .onAppear {
                    self.position2[0] = CGFloat(self.proteinPosition[0])
                    self.position2[1] = CGFloat(self.proteinPosition[1])
                    
            }
            RoundedRectangle(cornerRadius:30)
                .fill(Color(red:0.4,green:0.7,blue:0.7))
                .frame(width:80, height:40)
                .offset(x: position3[0], y: position3[1])
                .animation(.linear(duration: 1))
                .onAppear {
                    self.position3[0] = CGFloat(self.greasePosition[0])
                    self.position3[1] = CGFloat(self.greasePosition[1])
                    
            }
            
            
            
            Text("碳水\(Int(percentages[0]))％")
                .offset(x:position1[0],y:position1[1])
                .animation(.linear(duration: 1))
                .onAppear {
                    self.position1[0] = CGFloat(self.carbohydratePosition[0])
                    self.position1[1] = CGFloat(self.carbohydratePosition[1])
                    
            }
            Text("蛋白\(Int(percentages[1]))％")
                .offset(x: position2[0], y: position2[1])
                .animation(.linear(duration: 1))
                .onAppear {
                    self.position2[0] = CGFloat(self.proteinPosition[0])
                    self.position2[1] = CGFloat(self.proteinPosition[1])
                    
            }
            Text("油脂\(Int(percentages[2]))％")
                .offset(x: position3[0], y: position3[1])
                .animation(.linear(duration: 1))
                .onAppear {
                    self.position3[0] = CGFloat(self.greasePosition[0])
                    self.position3[1] = CGFloat(self.greasePosition[1])
                    
            }
            Text("總熱量：\(totalHot)大卡")
                .font(.system(size: 30))
            Group{
                Text("碳水\(Int(totalCarbohydrate))克")
                    .offset(y:200)
                Text("蛋白\(Int(totalProtein))克")
                    .offset(y:220)
                Text("油脂\(Int(totalGrease))克")
                    .offset(y:240)
            }
            
        }
        .frame(width: 300, height: 300)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(loversData : LoversData())
    }
}
