//
//  AppView.swift
//  hw2
//
//  Created by User19 on 2020/4/13.
//  Copyright © 2020 ntou. All rights reserved.
//
import SwiftUI


struct AppView: View {
    @ObservedObject var loversData = LoversData()
    var body: some View {
        TabView {
            LoverList(loversData : self.loversData)
                .tabItem {
                    Image(systemName: "mappin")//SF Symbol
                    Text("食物紀錄")
            }
            ContentView(loversData : self.loversData)
                .tabItem {
                    Image(systemName: "wand.and.rays.inverse")//SF Symbol
                    Text("總量計算")
            }
        }
       
    }
}

struct AppView_Previews: PreviewProvider {
    static var previews: some View {
        AppView()
        //.environment(\.colorScheme, .dark)
    }
}
