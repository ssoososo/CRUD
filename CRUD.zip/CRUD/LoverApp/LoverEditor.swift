//
//  LoverEditor.swift
//  LoverApp
//
//  Created by SHIH-YING PAN on 2020/4/29.
//  Copyright © 2020 SHIH-YING PAN. All rights reserved.
//

import SwiftUI

struct LoverEditor: View {
    @Environment(\.presentationMode) var presentationMode
    var loversData: LoversData
    @State private var name = ""
    @State private var carbohydrate = 0
    @State private var protein = 0
    @State private var grease = 0
    var editLover: Lover?
    func check(number: Int) -> Double {
        if(carbohydrate == 0 && protein == 0 && grease == 0){return 0}
        else {return Double(number)/(Double(self.carbohydrate)+Double(self.protein)+Double(self.grease))*360}
        
    }
    
    
    
    var body: some View {
        
        
        VStack {
            Form {
                TextField("食物名稱", text: $name)
                /*Stepper("碳水 \(Carbohydrate)", value: $Carbohydrate, in: 30...100)*/
                TextField("碳水", value: $carbohydrate, formatter:NumberFormatter())
                TextField("蛋白", value: $protein, formatter: NumberFormatter())
                TextField("油脂", value: $grease, formatter: NumberFormatter())
                
                
                
            }
            .navigationBarTitle(editLover == nil ? "Add new food":"Edit food")
            .navigationBarItems(trailing: Button("Save") {
                
                let lover = Lover(name: self.name, carbohydrate: self.carbohydrate,protein:self.protein,grease:self.grease)
                
                if let editLover = self.editLover {
                    let index = self.loversData.lovers.firstIndex {
                        $0.id == editLover.id
                        }!
                    self.loversData.lovers[index] = lover
                } else {
                    self.loversData.lovers.insert(lover, at: 0)
                }
                
                
                self.presentationMode.wrappedValue.dismiss()
            })
                .onAppear {
                    
                    if let editLover = self.editLover {
                        self.name = editLover.name
                        self.carbohydrate = editLover.carbohydrate
                        self.protein = editLover.protein
                        self.grease = editLover.grease
                    }
            }
            ZStack {
                Group{
                    Path { (path) in
                        path.move(to: CGPoint(x: 200, y: 200))
                        path.addArc(center: CGPoint(x: 200, y: 200), radius:
                            100, startAngle: .degrees(270), endAngle:.degrees(270+check(number:self.carbohydrate)), clockwise: false)
                    }
                    .fill(Color.yellow)
                    
                    Path { (path) in
                        path.move(to: CGPoint(x: 200, y: 200))
                        path.addArc(center: CGPoint(x: 200, y: 200), radius:
                            100, startAngle: .degrees(270+check(number:self.carbohydrate)), endAngle:.degrees(270+check(number:self.carbohydrate)+check(number:self.protein)), clockwise: false)
                    }
                    .fill(Color.blue)
                    
                    
                    Path { (path) in
                        path.move(to: CGPoint(x: 200, y: 200))
                        path.addArc(center: CGPoint(x: 200, y: 200), radius:
                            100, startAngle: .degrees(270+check(number:self.carbohydrate)+check(number:self.protein)), endAngle:.degrees(270), clockwise: false)
                    }
                    .fill(Color.red)
                    //text
                    Path { (path) in
                        path.move(to: CGPoint(x: 300, y: 21))
                        path.addArc(center: CGPoint(x: 300, y: 21), radius:
                            6, startAngle: .degrees(0), endAngle:.degrees(360), clockwise: false)
                    }
                    .fill(Color.yellow)
                    Text("碳水\(Int(check(number: carbohydrate)/3.6))%")
                        .offset(x:140,y:-150)
                    
                    Path { (path) in
                        path.move(to: CGPoint(x: 300, y: 41))
                        path.addArc(center: CGPoint(x: 300, y: 41), radius:
                            6, startAngle: .degrees(0), endAngle:.degrees(360), clockwise: false)
                    }
                    .fill(Color.blue)
                    Text("蛋白\(Int(check(number: protein)/3.6))%")
                        .offset(x:140,y:-130)
                    
                    Path { (path) in
                        path.move(to: CGPoint(x: 300, y: 61))
                        path.addArc(center: CGPoint(x: 300, y: 61), radius:
                            6, startAngle: .degrees(0), endAngle:.degrees(360), clockwise: false)
                    }
                    .fill(Color.red)
                    Text("油脂\(Int(check(number: grease)/3.6))%")
                        .offset(x:140,y:-110)
                    
                    
                    
                    
                }
                
                
                
            }
            
            
        }
        
    }
    
}

struct LoverEditor_Previews: PreviewProvider {
    static var previews: some View {
        LoverEditor(loversData: LoversData())
    }
}
