//
//  LoverRow.swift
//  LoverApp
//
//  Created by SHIH-YING PAN on 2020/4/29.
//  Copyright © 2020 SHIH-YING PAN. All rights reserved.
//

import SwiftUI

struct LoverRow: View {
    var lover: Lover
   
    var body: some View {
        HStack {
            Text(lover.name)
            Spacer()
            Text("碳水\(lover.carbohydrate) g")
                .font(.footnote)
            Text("蛋白\(lover.protein) g")
            .font(.footnote)
            Text("油脂\(lover.grease) g")
            .font(.footnote)
            Text("熱量\(lover.carbohydrate*4+lover.protein*4+lover.grease*9)kal")
            /*Image(systemName: lover.trueHeart ? "heart.fill" : "heart")*/
        }

    }
}

struct LoverRow_Previews: PreviewProvider {
    static var previews: some View {
        LoverRow(lover: Lover(name: "chiken", carbohydrate: 45, protein: 10,grease:15))
            
            .previewLayout(.sizeThatFits)
    }
}
